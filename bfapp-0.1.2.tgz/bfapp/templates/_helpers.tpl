{{/*
Expand the name of the chart.
*/}}
{{- define "bfapp.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "bfapp.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "bfapp.backend.fullname" -}}
backend-{{ include "bfapp.fullname" . }}
{{- end }}

{{- define "bfapp.frontend.fullname" -}}
frontend-{{ include "bfapp.fullname" . }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "bfapp.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "bfapp.labels" -}}
helm.sh/chart: {{ include "bfapp.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "bfapp.frontend.labels" -}}
{{ include "bfapp.frontend.selectorLabels" . }}
{{ include "bfapp.labels" . }}
{{- end }}

{{- define "bfapp.backend.labels" -}}
{{ include "bfapp.backend.selectorLabels" . }}
{{ include "bfapp.labels" . }}
{{- end }}


{{/*
Selector labels
*/}}
{{- define "bfapp.selectorLabels" -}}
app.kubernetes.io/name: {{ include "bfapp.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

# Frontend
{{- define "bfapp.frontend.selectorLabels" -}}
{{ include "bfapp.selectorLabels" . }}
app.kubernetes.io/component: frontend
{{- end }}

# Backend
{{- define "bfapp.backend.selectorLabels" -}}
{{ include "bfapp.selectorLabels" . }}
app.kubernetes.io/component: backend
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "bfapp.frontend.serviceAccountName" -}}
{{- if .Values.frontend.serviceAccount.create }}
{{- default (include "bfapp.frontend.fullname" .) .Values.frontend.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.frontend.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "bfapp.backend.serviceAccountName" -}}
{{- if .Values.backend.serviceAccount.create }}
{{- default (include "bfapp.backend.fullname" .) .Values.backend.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.backend.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "bfapp.backend.envSecret" -}}
{{ include "bfapp.fullname" . }}-env
{{- end }}
