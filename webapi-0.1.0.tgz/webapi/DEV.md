https://helm.sh/docs/chart_template_guide/debugging/

helm template --release-name 2312-cambio1 temporal-webapi > output.yml 

--debug 